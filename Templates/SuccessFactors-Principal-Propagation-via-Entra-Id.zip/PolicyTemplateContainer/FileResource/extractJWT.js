var req = context.getVariable("request.header.Authorization");

if(!req) throw "Missing Auth Header";

//split token by key word Bearer, Basic etc.
var parts = req.split(" ");

//assign Entra ID JWT token to variable for reference in policies for processing
if(parts.length == 2){
    context.setVariable("private.bearerToken", parts[1]);
}else{
    throw "token missing";
}

var verb = context.getVariable("request.verb");
//var precondition = context.getVariable("request.header.If-Match");

//handle etag. Policy assumes pre condition by default. Skip here and in polcies using variable if dealt with by consumer instead.
/*if(verb != "GET" && verb != "HEAD"){
    if(precondition != null){
        context.setVariable("precondition", precondition);
    }else{
        throw "precondition expected by SAP APIM!";
    }
}*/
//set content type for dynamic service callouts before the intended OData request
context.setVariable("mycontenttype", context.getVariable("request.header.Content-Type"));